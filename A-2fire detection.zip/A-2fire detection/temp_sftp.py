import pysftp as sftp #dependency modules : pysftp->paramiko->pycrypto
import time
import os
from random import randrange

def FireAlarmSimulation():
	num = randrange(10)
	if num==0:
		status = 'FIRE..'
	elif num==1:
		status = 'NORMAL..'
	elif num==2:
		status = 'NORMAL..'
	elif num==3:
		status = 'NORMAL..'
	elif num==4:
		status = 'NORMAL..'
	elif num==5:
		status = 'NORMAL..'
	elif num==6:
		status = 'NORMAL..'
	elif num==7:
		status = 'NORMAL..'
	elif num==8:
		status = 'NORMAL..'
	elif num==9:
		status = 'BATTERY DOWN..'

	fireFile = open('FILERECORD.txt', "w+")
	fireFile.write(status)
	fireFile.close()

def sftpConnect(host, username, password):
	try:

		s = sftp.Connection(host, username, password)
		remotepath='/home/'+username+'/FILERECORD.txt'
		localpath='/home/'+username+'/FILERECORD.txt'

#The Connection object is the base of pysftp. It supports connections via username and password.

		s.get(remotepath, localpath)

#Copies a file between the remote host and the local host.

		s.close
#Closes the connection and cleans up.

	except Exception, e:
		print 'failed', str(e)

def ServerMonitor():
	checkFireFile = open('FILERECORD.txt',"r+")
	print checkFireFile.read()
	checkFireFile.close()

def main():
	choice = int(raw_input("MENU\n1. FIRE ALARM\n2. SERVER\nENTER YOUR CHOICE : "))
	if choice==1:
		print("INPUT THE BELOW IP ADDRESS IN THE SERVER..")
		os.system("ifconfig")

		print("FIRE ALARM SENSOR STARTED SUCCESSFULLY..")
		while 1 :
			FireAlarmSimulation()
			time.sleep(5)

	elif choice==2:
		host = raw_input("ENTER IP ADDRESS : ")
		username = raw_input("ENTER USERNAME : ")
		password = raw_input("ENTER PASSWORD : ")

		while 1 :	
			sftpConnect(host,username,password)
			ServerMonitor()
			time.sleep(5)

main()
